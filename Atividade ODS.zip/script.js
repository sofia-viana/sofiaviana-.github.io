 
    function enviarWhatsApp() {
      const nome = document.getElementById("nome").value.trim();
      const mensagem = document.getElementById("mensagem").value.trim();
      const myselect = document.getElementById("myselect").value.trim();
      const dados = document.getElementById("dados").value.trim();

      if (!nome || !mensagem || !myselect || !dados ) {
        alert("Por favor, preencha todos os campos.");
        return;
      }
    
      const texto = `Nome: ${nome}\nMensagem: ${mensagem}\nmyselect: ${myselect}\ndados: ${dados}`;
      const textoCodificado = encodeURIComponent(texto);

    
      window.open("https://api.whatsapp.com/send?phone=5581999038113&text=" + textoCodificado, "_blank");
    }
